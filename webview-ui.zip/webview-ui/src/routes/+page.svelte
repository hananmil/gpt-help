<script lang="ts">
	import SearchBox from './chat/SearchBox.svelte';
	import ChatArea from './chat/ChatArea.svelte';

	import { onMount } from 'svelte';

	// import { allComponents, provideVSCodeDesignSystem } from '@vscode/webview-ui-toolkit';
	import { MessageFormatter } from './messageFormatter.service';
	import { sysutils } from './chat/sysUtils';

	let messageFormatter: MessageFormatter;

	// provideVSCodeDesignSystem().register(allComponents);

	let searchBox: SearchBox;
	let chatArea: ChatArea;

	function handleKeyDown(event: any) {
		if (event.keyCode === 13 && event.ctrlKey) {
			searchBox.sendMessage();
		}
	}

	function updateBottomHeight() {
		const bottomHeight = (document.querySelector('.bottom-section') as HTMLElement).offsetHeight;
		document.documentElement.style.setProperty('--input-height', bottomHeight + 'px');
	}

	onMount(() => {
		updateBottomHeight();
		sysutils.addEventListener('resize', updateBottomHeight);

		messageFormatter = new MessageFormatter();
		chatArea.searchBox.messages = chatArea.messages;
	});
</script>

<vscode-panel-view orientation="horizontal" aria-label="Default" on:keydown={handleKeyDown}>
	<ChatArea bind:this={chatArea} />
	<SearchBox bind:this={searchBox} />
</vscode-panel-view>

<style>
	:root {
		--input-height: 0;
	}

	vscode-panel-view {
		background-color: var(--vscode-editor-background);
		color: var(--vscode-foreground);
		height: 100%;
		position: relative;
		display: flex;
		align-content: flex-start;
		flex-direction: column;
		justify-content: space-between;
	}
</style>
