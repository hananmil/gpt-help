export const sysutils = {
    localStorageGet: (key: string) => {
        try {
            const json = window.localStorage.getItem(key);
            return json ? JSON.parse(json) : null;
        } catch (e) {
            console.warn("Error reading cache", e);
            return null;
        }
    },
    localStorageSet: (key: string, value: any) => {
        try {
            window.localStorage
                .setItem(key, JSON.stringify(value));
        } catch (e) {
            console.warn("Error writing cache", e);
        }

    },
    postMessage: (message: any) => {
        console.log("Posting message", message);
        window?.postMessage(message);
    },
    addEventListener: (type: string, listener: (event: any) => void) => {
        window?.addEventListener(type, listener);
    }
}