/// <reference types="svelte" />


type VSCode = {
    postMessage(message: never): void;
    getState(): never;
    setState(state: never): void;
    process: VSCodeproccess;
};

type VSCodeproccess = {
    on(func: (...arg: never[]) => void): void;
};

declare const vscode: VSCode;
